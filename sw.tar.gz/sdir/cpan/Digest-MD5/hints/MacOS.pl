# MWCPPC compiler needs to crank down the optimizations

use strict;
no strict 'vars';
$self->{MWCPPCOptimize} = "-O1";
